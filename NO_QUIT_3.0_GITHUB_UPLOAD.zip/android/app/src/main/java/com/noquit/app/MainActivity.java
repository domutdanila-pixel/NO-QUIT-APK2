package com.noquit.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Color;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileUploadCallback;
    private static final int FILE_CHOOSER_REQUEST = 4103;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,10,11));
        getWindow().setNavigationBarColor(Color.rgb(9,10,11));
        web = new WebView(this); web.setBackgroundColor(Color.rgb(9,10,11));
        WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileUploadCallback != null) fileUploadCallback.onReceiveValue(null);
                fileUploadCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileUploadCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        }); web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9001);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileUploadCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileUploadCallback.onReceiveValue(results);
            fileUploadCallback = null;
        }
    }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    public class Bridge {
        Context c; Bridge(Context c){this.c=c;}
        @JavascriptInterface public void callChatApi(String base,String key,String payload,String callbackId){
            new Thread(()->{
                String result=""; boolean ok=false;
                for(int attempt=0;attempt<3;attempt++){
                    HttpURLConnection conn=null;
                    try{
                        String cleanBase=base==null?"":base.trim().replaceAll("/+$","");
                        if(cleanBase.isEmpty())throw new Exception("Не указан API Base URL");
                        if(key==null||key.trim().isEmpty())throw new Exception("Не указан API-ключ");
                        URL url=new URL(cleanBase+"/chat/completions");
                        conn=(HttpURLConnection)url.openConnection();
                        conn.setRequestMethod("POST");conn.setConnectTimeout(20000);conn.setReadTimeout(60000);conn.setDoOutput(true);
                        conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                        conn.setRequestProperty("Authorization","Bearer "+key.trim());
                        byte[] bytes=payload.getBytes("UTF-8");conn.setFixedLengthStreamingMode(bytes.length);
                        try(OutputStream os=conn.getOutputStream()){os.write(bytes);}
                        int code=conn.getResponseCode();
                        java.io.InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
                        StringBuilder sb=new StringBuilder();
                        if(stream!=null)try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,"UTF-8"))){String line;while((line=br.readLine())!=null){if(sb.length()<1200)sb.append(line);}}
                        if(code<200||code>=300){
                            String body=sb.toString();
                            String lowerBody=body.toLowerCase(java.util.Locale.ROOT);
                            boolean quotaExhausted=lowerBody.contains("no credits")||lowerBody.contains("insufficient_quota")||lowerBody.contains("insufficient credits")||lowerBody.contains("billing");
                            boolean retry=(code==502||code==503||code==504||(code==429&&!quotaExhausted));
                            if(retry&&attempt<2){
                                int wait=1000*(1<<attempt);
                                String retryAfter=conn.getHeaderField("Retry-After");
                                try{if(retryAfter!=null)wait=Math.min(15000,Math.max(wait,Integer.parseInt(retryAfter.trim())*1000));}catch(Exception ignored){}
                                conn.disconnect();conn=null;Thread.sleep(wait);continue;
                            }
                            String detail=body.isEmpty()?"Сервер не вернул описание ошибки":body;
                            if(code==401||code==403)throw new Exception("API "+code+": проверь API-ключ и права доступа. "+detail);
                            if(code==404)throw new Exception("API 404: проверь адрес API и точный ID модели. "+detail);
                            if(code==429)throw new Exception("API 429: лимит или баланс провайдера. Проверь квоты, биллинг и ограничения модели. "+detail);
                            if(code==503)throw new Exception("API 503: модель временно перегружена. Повторные попытки не помогли. "+detail);
                            throw new Exception("API "+code+": "+detail);
                        }
                        JSONObject data=new JSONObject(sb.toString());JSONArray choices=data.optJSONArray("choices");
                        if(choices==null||choices.length()==0)throw new Exception("Провайдер вернул пустой список ответов");
                        result=choices.getJSONObject(0).getJSONObject("message").optString("content","").trim();
                        if(result.isEmpty())throw new Exception("Модель вернула пустой ответ");ok=true;break;
                    }catch(java.io.IOException e){
                        result="Сетевая ошибка: "+(e.getMessage()==null?"проверь интернет-соединение":e.getMessage());
                        if(attempt<2){try{Thread.sleep(1000*(1<<attempt));}catch(InterruptedException ignored){}continue;}
                    }catch(Exception e){result=e.getMessage()==null?"Ошибка соединения":e.getMessage();break;}
                    finally{if(conn!=null)conn.disconnect();}
                }
                final boolean success=ok;final String answer=result;
                runOnUiThread(()->{String js="window.onNativeAIResult && window.onNativeAIResult("+JSONObject.quote(callbackId)+","+success+","+JSONObject.quote(answer)+")";web.evaluateJavascript(js,null);});
            }).start();
        }
        @JavascriptInterface public void shareText(String filename,String content,String mime){
            runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType(mime==null?"text/plain":mime);i.putExtra(Intent.EXTRA_SUBJECT,filename);i.putExtra(Intent.EXTRA_TEXT,content);startActivity(Intent.createChooser(i,"Экспорт NO QUIT"));});
        }
        @JavascriptInterface public void scheduleDaily(String key,int hour,int minute,String title,String body){
            int id=key.equals("morning")?4101:4102; Intent i=new Intent(c,ReminderReceiver.class);i.putExtra("title",title);i.putExtra("body",body);i.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            java.util.Calendar cal=java.util.Calendar.getInstance();cal.set(java.util.Calendar.HOUR_OF_DAY,hour);cal.set(java.util.Calendar.MINUTE,minute);cal.set(java.util.Calendar.SECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(java.util.Calendar.DAY_OF_YEAR,1);
            AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE); if(am!=null)am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
            runOnUiThread(()->Toast.makeText(c,"Ежедневное напоминание сохранено",Toast.LENGTH_SHORT).show());
        }
    }
}
