# NO QUIT 3.0 — Architecture decisions

**Status:** Product decisions confirmed by the owner 2026-11-13  
**Baseline:** NO QUIT 2.2 personal Android project  
**Product direction:** Personal Operating System

## 1. Confirmed owner decisions

| Decision | Selected option | Architectural consequence |
|---|---|---|
| Primary currency | RUB | RUB is the default display/reporting currency and default currency for new manual entries. Other currencies remain selectable per operation. |
| Money tracking | Manual | No bank connections, payment initiation, card access, or automatic transaction import in the first major release. The user enters and edits transactions. |
| Data storage | Local | The device is the source of truth. No mandatory cloud account or server sync. Backup/export is user-initiated and stored where the user chooses. |
| First major release priority | Finance, deals, achievements | Deliver Wallet, Deal Room, and Achievements as the first complete product modules. Other modules remain later roadmap items. |

## 2. Product modules and delivery order

### Release 3.0 — first major release

1. **HOME / Command Center shell** — configurable overview of verified wallet balances, monthly cash flow, active deals, goals and upcoming actions. A metric is hidden or marked unavailable until its source exists.
2. **WALLET / Finance**
   - Manual income, expense, and balance-adjustment entries.
   - RUB default currency; operation-level currency selection for USD, EUR, AED, GBP and additional currencies when configured.
   - Separate balances by currency. Never add unlike currencies without an explicit exchange-rate record.
   - Transaction fields: stable ID, type, amount, currency, date/time, category, description, optional attachment/reference, created/updated timestamps.
   - Edit, delete with confirmation, filter, search, monthly summaries, export.
   - No bank integration or money transfers to external accounts.

3. **DEAL ROOM / Deals**
   - Track objects, counterparties, investors, stage, next action, dates, documents/links, expected commission, partner shares, expenses and actual received amount.
   - Pipeline stages: NEW, NEGOTIATION, CONTRACT, CLOSING, CLOSED; additional states ON_HOLD, DECLINED, UNVERIFIED.
   - Expected, contracted, and received amounts must be distinct fields/states.
   - A deal must never increase Wallet balance merely because it is signed, marked closed, or expected to pay. Only an explicit user-created receipt transaction affects actual balance.
   - Optional link from a deal to a Wallet transaction for reconciliation; prevent duplicate income entries.

4. **PROGRESS / Achievements**
   - Achievement catalog with title, description, criteria, icon/art, status, achieved date and optional evidence/note.
   - Financial milestones are derived only from actual Wallet receipts, net of configured partner shares/expenses where the user records them; do not count pipeline estimates.
   - Manual/custom achievements remain available for non-financial milestones.
   - Achievement awarding must be explainable and reversible if source data is corrected.

### Later releases

- Expanded GOALS and weekly planning.
- AI Advisor and provider/model management.
- Focus Mode, Private Journal, Vision Board, Analytics, Personal Vault, Legacy timeline.

## 3. Local-first data architecture

- Device-local database is the canonical source of truth for finance, deals and achievements.
- Do not require login, cloud account, or network connection for core CRUD and reports.
- Keep persistence behind repository/data-access interfaces so storage can evolve without rewriting UI/business logic.
- Use stable IDs and schema versioning. Every schema change requires a migration and a tested upgrade path from the current 2.2 data format.
- User-initiated backup/restore must include Wallet transactions, currencies/rates if present, deals, counterparties, achievements, settings and attachment references.
- Backup format must include a schema version, creation timestamp and integrity check. Restore must validate before replacing current data and should offer a pre-restore backup.
- Protect sensitive local data where feasible using Android secure storage/Keystore-backed encryption. Do not log API keys, journal contents or financial details.
- Local-first does not mean "no backup": clearly remind users to export backups because uninstalling or losing the device can destroy local-only data.

## 4. Financial integrity rules

- Store monetary values as integer minor units (kopecks/cents/fils) or an exact decimal representation; never use binary floating point for ledger arithmetic.
- Every transaction has exactly one currency.
- Currency conversion is a separate explicit operation using a recorded rate, rate date/source and rounding policy.
- RUB is the default reporting currency, but converted totals must show that they are estimates and display the rate timestamp/source.
- Do not infer income from deal values, property values, signed contracts, projected fees, or AI-generated estimates.
- Wallet balance = opening balance + recorded income - recorded expenses + explicit adjustments/transfers, calculated independently per currency.
- Internal transfers between tracked accounts must net to zero at portfolio level and must not be counted as income or expense.
- Deleted/edited transactions must update derived reports and achievement progress consistently.

## 5. AI and privacy boundaries

- AI is optional and never required for core finance/deal/achievement features.
- By default, no Wallet, Deal Room, Journal or Vault content is sent to an AI provider.
- AI context sharing must be opt-in, granular by module, and previewable before sending.
- API credentials must not be embedded in source code, APK assets, repository history or logs. Use Android-protected local storage for a personal build; use a secured server-side proxy for a public multi-user product.
- Provider/model availability, pricing and quotas must be treated as dynamic; show provider errors accurately and do not promise free usage.

## 6. Navigation and interface

### Bottom navigation — five items, four primary destinations + More

The persistent bottom bar must contain exactly five destinations:

1. **HOME** — Command Center.
2. **WALLET** — finance.
3. **DEALS** — Deal Room.
4. **PROGRESS** — goals, achievements and Legacy.
5. **MORE** — a compact directory for secondary tools and settings.

Do not add AI Advisor, Journal, Focus Mode, Vision Board, Analytics, Vault, Stories, Quotes or Settings as separate bottom-bar items. They belong inside MORE or may be opened contextually from a relevant screen. This keeps the bottom bar readable and prevents navigation overload.

MORE directory groups secondary modules: AI Advisor/provider settings, Focus Mode, Private Journal, Vision Board, Analytics, Personal Vault, Legacy (if not surfaced in PROGRESS), Investors, backup/restore, notifications and app settings. Items not yet implemented must be clearly marked as planned or unavailable; do not present placeholders as working features.

The active main tab should remain MORE when a secondary screen (for example AI Advisor or Settings) is open. HOME, WALLET, DEALS, PROGRESS and MORE remain the only persistent bottom destinations.

### Design

Visual direction: Quiet Luxury / Private Banking / Premium Fintech; Obsidian Black, Graphite, Muted Gold, Bronze and Warm White. Use restrained typography, accessible contrast, compact cards, subtle motion and responsive Android layouts. Avoid loud gradients, excessive badges, dense dashboards and unnecessary controls.

HOME widgets should be configurable by visibility and order. The main screen must prioritize current balance, actual capital, monthly income/expenses, active deals, weekly goal completion, level/productive-day metrics and upcoming actions. Any metric without a reliable source should be hidden or explicitly marked as not yet tracked.

## 7. Migration and acceptance criteria

- Preserve existing 2.2 settings, diary entries, reminders and other user data.
- Migrate existing wallet records without changing amounts, dates or currencies.
- Set primary/default currency to RUB without rewriting historical transaction currencies.
- Keep the manual-entry model and local-only storage as defaults.
- Test offline creation/editing/deletion and restart persistence.
- Test multi-currency totals, rounding, conversion metadata and internal transfers.
- Test that expected/contracted deal commissions never alter actual Wallet balance.
- Test deal-to-receipt linking and duplicate prevention.
- Test achievement recalculation after edits/deletions and distinguish manual from derived achievements.
- Test backup/restore across app restart and schema migration from 2.2.
- Test that no personal data is sent to AI without explicit opt-in.

## 8. Explicit non-goals for the first major release

- Bank account aggregation or open-banking connections.
- Sending, receiving or transferring real money.
- Automatic transaction scraping/import.
- Mandatory cloud synchronization or account registration.
- Counting expected commissions or asset valuations as liquid cash.
- AI making financial ledger changes without user confirmation.

---

**Product rule:** NO QUIT records what the user actually did and actually received. Forecasts, ambitions and potential deals are valuable, but they must never be confused with verified results.


## 9. Delivery scope and implementation truth

The current Android/WebView baseline is not yet a completed NO QUIT 3.0. Existing 2.2 functionality must be preserved while modules are implemented incrementally. The current navigation shell exposes HOME, WALLET, DEALS, PROGRESS and MORE; Deal Room and expanded Progress are navigation shells until their underlying data models and workflows are implemented. A visible navigation entry is not evidence that its module is production-ready.


## Implementation snapshot — 2026-11-13

The current implementation milestone adds working local-first UI and data flows for Wallet, Deal Room, and Progress while retaining the existing 2.2 application screens. New transaction amounts are stored as integer minor units; legacy 2.2 amounts remain readable without destructive conversion. Internal transfers use paired ledger entries and do not affect aggregate capital or income/expense totals. Deal commissions remain pipeline metadata and never create Wallet entries automatically. The backup format is versioned (`schemaVersion: 3`) and includes deals, goals, and achievements.

This milestone still uses WebView `localStorage`, not a relational database. It does not yet implement encrypted vault storage, exchange-rate feeds/conversion, file attachments, investor CRM records as a separate entity, full edit/search/filter flows, or full analytics. The Android APK has not been built or device-tested in this environment; these remain release acceptance tasks.
