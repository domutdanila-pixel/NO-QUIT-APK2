NO QUIT 3.0 — PERSONAL MOTIVATION APP

This build intentionally removes CRM/deal-management modules.

Core screens:
- HOME: balance snapshot, daily quote, motivational story, monthly summary.
- WALLET: manual income/expense entries in separate currencies (RUB, USD, EUR, AED, GBP), transaction history, charts.
- INSPIRATION: add, favorite and delete personal quotes and stories.
- CALENDAR: monthly calendar with income/expense markers and selected-day breakdown.
- AI MOTIVATOR: OpenAI-compatible API connection and local offline motivational replies.

Data is stored locally in WebView localStorage. No server or account is required for core functionality.
Currency balances are kept separate; no automatic exchange-rate conversion is performed.
AI API key is currently stored in local app storage for this personal prototype. Do not distribute this build with a real key. A production release should move secrets to Android Keystore-backed storage.

Android project: ./android
GitHub Actions workflow: ./.github/workflows/build-apk.yml
