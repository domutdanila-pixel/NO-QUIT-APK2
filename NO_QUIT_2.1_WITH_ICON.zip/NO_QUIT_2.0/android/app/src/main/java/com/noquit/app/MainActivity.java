package com.noquit.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.graphics.Color;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONObject;
import org.json.JSONArray;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(9,10,11));
        getWindow().setNavigationBarColor(Color.rgb(9,10,11));
        web = new WebView(this); web.setBackgroundColor(Color.rgb(9,10,11));
        WebSettings settings=web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(false);
        web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9001);
    }
    @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    public class Bridge {
        Context c; Bridge(Context c){this.c=c;}
        @JavascriptInterface public void callChatApi(String base,String key,String payload,String callbackId){
            new Thread(()->{
                HttpURLConnection conn=null; String result=""; boolean ok=false;
                try{
                    URL url=new URL(base.replaceAll("/$","")+"/chat/completions"); conn=(HttpURLConnection)url.openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(45000); conn.setDoOutput(true); conn.setRequestProperty("Content-Type","application/json"); conn.setRequestProperty("Authorization","Bearer "+key);
                    byte[] bytes=payload.getBytes("UTF-8"); try(OutputStream os=conn.getOutputStream()){os.write(bytes);}
                    int code=conn.getResponseCode(); java.io.InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
                    StringBuilder sb=new StringBuilder(); try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,"UTF-8"))){String line;while((line=br.readLine())!=null)sb.append(line);}
                    if(code<200||code>=300) throw new Exception("API "+code+": "+sb.toString().substring(0,Math.min(180,sb.length())));
                    JSONObject data=new JSONObject(sb.toString()); JSONArray choices=data.optJSONArray("choices"); if(choices==null||choices.length()==0)throw new Exception("Пустой ответ модели"); result=choices.getJSONObject(0).getJSONObject("message").optString("content","").trim(); if(result.isEmpty())throw new Exception("Модель вернула пустой ответ"); ok=true;
                }catch(Exception e){result=e.getMessage()==null?"Ошибка соединения":e.getMessage();}finally{if(conn!=null)conn.disconnect();}
                final boolean success=ok; final String answer=result; runOnUiThread(()->{String js="window.onNativeAIResult && window.onNativeAIResult("+JSONObject.quote(callbackId)+","+success+","+JSONObject.quote(answer)+")";web.evaluateJavascript(js,null);});
            }).start();
        }
        @JavascriptInterface public void shareText(String filename,String content,String mime){
            runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_SEND);i.setType(mime==null?"text/plain":mime);i.putExtra(Intent.EXTRA_SUBJECT,filename);i.putExtra(Intent.EXTRA_TEXT,content);startActivity(Intent.createChooser(i,"Экспорт NO QUIT"));});
        }
        @JavascriptInterface public void scheduleDaily(String key,int hour,int minute,String title,String body){
            int id=key.equals("morning")?4101:4102; Intent i=new Intent(c,ReminderReceiver.class);i.putExtra("title",title);i.putExtra("body",body);i.putExtra("id",id);
            PendingIntent pi=PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            java.util.Calendar cal=java.util.Calendar.getInstance();cal.set(java.util.Calendar.HOUR_OF_DAY,hour);cal.set(java.util.Calendar.MINUTE,minute);cal.set(java.util.Calendar.SECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(java.util.Calendar.DAY_OF_YEAR,1);
            AlarmManager am=(AlarmManager)c.getSystemService(ALARM_SERVICE); if(am!=null)am.setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
            runOnUiThread(()->Toast.makeText(c,"Ежедневное напоминание сохранено",Toast.LENGTH_SHORT).show());
        }
    }
}
