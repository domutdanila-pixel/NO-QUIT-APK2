package com.noquit.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String channel="noquit_daily"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(channel,"NO QUIT reminders",NotificationManager.IMPORTANCE_DEFAULT));
  String title=i.getStringExtra("title"),body=i.getStringExtra("body");int id=i.getIntExtra("id",4100);
  android.app.Notification n=new NotificationCompat.Builder(c,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title==null?"NO QUIT":title).setContentText(body==null?"Вернись к своему пути.":body).setAutoCancel(true).build();nm.notify(id,n);
 }
}
