NO QUIT 2.0 — Android Studio project
Open this android/ folder in Android Studio. Install SDK Platform 35 if prompted, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). Debug APK output: app/build/outputs/apk/debug/app-debug.apk.

The app uses local WebView assets, localStorage for personal diary and settings, OpenAI-compatible API when configured, offline fallback chat, Android share sheet for exports, and daily notification alarms.
