NO QUIT 2.0 — Android project

What is included:
- Premium dark bronze/gold interface.
- 4 support modes (heavy day, hard push, loss of confidence, progress audit).
- Offline fallback chat and OpenAI-compatible chat API configuration.
- API endpoint/model/key fields in Settings.
- 300+ motivational thoughts (original NO QUIT editorial content plus attributed quotations; attributions should be checked before publication).
- 50 short biographies / business stories with source pointers.
- Searchable story library.
- Local diary, favorites, chat history, progress counters.
- TXT diary export and JSON backup/import.
- Android daily reminder bridge (requires notification permission).

AI SECURITY:
This is a personal BYOK build. The API key is stored in app WebView local storage and can be extracted from a rooted/compromised device or a repackaged APK. Never distribute a build containing your key. For a public release, put provider keys on a backend proxy with authentication, rate limits, and abuse controls.

Build APK:
Open the android/ folder in Android Studio, install Android SDK Platform 35 if prompted, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s). Output: android/app/build/outputs/apk/debug/app-debug.apk

This workspace does not contain Android SDK or Gradle, so the APK has not been compiled here.

Cloud build option (no local Android SDK required):
1. Upload this project to a GitHub repository.
2. Open the repository's Actions tab.
3. Select "Build NO QUIT APK" and press "Run workflow".
4. Download the generated artifact named "NO-QUIT-debug-apk"; it contains app-debug.apk.
